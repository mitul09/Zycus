import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Product } from '../model/product.model';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})

// 7. A component for rendering all productRows & storing the currently selected products
export class ProductsListComponent implements OnInit {

  @Input() productList: Product[];
  @Output() onProductSelected: EventEmitter<Product>;

  //8. local state containning the currently selected `Product`
  private currentProduct: Product;

  constructor() {
    this.onProductSelected = new EventEmitter(); // local component state
  }

  ngOnInit(): void {
  }

  // 10. clicked nor isSelected
  // Set this.currentProduct to the Product that was passed in.
  // Emit the Product that was clicked on our output
  clicked(product: Product): void {
    this.currentProduct = product;
    this.onProductSelected.emit(product);
  }

  // 10. clicked nor isSelected
  isSelected(product: Product): boolean {
    if (!product || !this.currentProduct) {
      return false;
    }
    return product.sku === this.currentProduct.sku;
  }
}
