import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Movie } from '../model/movie.model';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MovieServiceService {

  // To make code loosely coupled
  private apiEndPoint = 'http://localhost:3900/api'
  private url = this.apiEndPoint + '/movies';

  constructor(private httpClient: HttpClient) { }

  // fetch all movies from backend
  public getAllMovies(): Observable<Movie[]> {
    return this.httpClient.get<Movie[]>(this.url)
      .pipe(
        catchError(this.handleError)
      )
  }

  //fetch a movie from backend based on given id
  public getMovie(id: string): Observable<Movie> {
    return this.httpClient.get<Movie>(this.url + '/' + id)
      .pipe(
        catchError(this.handleError)
      )
  }

  // making a common method for create(post) & update(put)
  public saveMovie(movie): Observable<Movie> {
    if (!movie._id) {
      //post: create new movie
      return this.httpClient.post<Movie>(this.url, movie)
        .pipe(
          catchError(this.handleError)
        )
    } else {
      // put: update the existing movie
      const movieToUpdate = {
        title: movie.title,
        numberInStock: movie.numberInStock,
        dailyRentalRate: movie.dailyRentalRate,
        genreId: movie.genre._id
      }
      return this.httpClient.put<Movie>(this.url + '/' + movie._id, movieToUpdate)
        .pipe(
          catchError(this.handleError)
        )
    }
  }

  //construct a delete request 
  public deleteMovie(id: string): Observable<Movie> {
    return this.httpClient.delete<Movie>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
    // avoid repetation
    // .pipe(
    //   catchError((error: HttpErrorResponse) => {
    //     if (error.status >= 400 && error.status < 500) {
    //       return throwError(error.error)
    //     } else {
    //       alert('Something went wrong')
    //       console.log('logging the error into logger')
    //       //......
    //       //...
    //     }
    //   })
    // )
  }

  // To make code loosely coupled
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      //client error 
      errorMessage = 'Error ' + error.error.message;
    } else {
      //server error 
      errorMessage = `Error Code : ${error.status} \n Message :  ${error.message}`
    }
    return throwError(errorMessage)
  }

}