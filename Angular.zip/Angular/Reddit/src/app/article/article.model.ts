// 4. Creating an Article class
// short cut way is also there

import { Injectable } from '@angular/core';

// Reason for making model class like this beacause When it comes to voteUp (and voteDown), 
// we don’t increment votes on the component, but rather, we need to increment the votes on the article.

export class Article {
    title: string;
    link: string;
    votes: number;

    constructor(title: string, link: string, votes?: number) {
        this.title = title;
        this.link = link;
        this.votes = votes || 0; //// optional default to 0
    }

    // 10. methods break the encapsulation of the Article class by changing the article’s internal properties directly
    voteUp(): void {
        this.votes += 1;
    }

    voteDown(): void {
        this.votes -= 1;
    }

    // domain() is a utility function that extracts
    // the domain from a URL, which we'll explain shortly
    domain(): string {
        try {
            // e.g. http://foo.com/path/to/bar
            const domainAndPath: string = this.link.split('//')[1];
            // e.g. foo.com/path/to/bar
            return domainAndPath.split('/')[0];
        } catch (err) {
            return null;
        }
    }
}

