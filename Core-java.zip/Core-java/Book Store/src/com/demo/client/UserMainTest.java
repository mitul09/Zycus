package com.demo.client;
import  com.demo.dao.UserDAO;
import com.demo.model.User;

import java.util.*;
public class UserMainTest {

	public static void main(String[] args)
	{
		//CRUD operations
		User user = null;
		UserDAO u1 = new UserDAO();
		System.out.println("*******");
		Scanner s= new Scanner(System.in);
		int i=0;
		while(i!=6)
		{
			System.out.println("menu\n");
			System.out.println("1.Create");
			System.out.println("2.Update");
			System.out.println("3.get a user");
			System.out.println("4.Delete a user");
			System.out.println("5.Get all users");
			System.out.println("6.Exit");
			i=s.nextInt();
			int n;
			switch(i)
			{
			case 1:
			{
				
				System.out.println("Enter Users name, email, password");
				n= u1.count() + 1;

				System.out.println("Enter Users name");
				String name = s.next();
				System.out.println("Enter Users email");
				String email = s.next();
				System.out.println("Enter Users  password");

				String pass = s.next();
				user = new User(n,email,pass,name);
				u1.create(user);
				if(n==u1.count())
					System.out.println("user added:"+user);
				else
					System.out.println("user adding error");
				break;
			}
			case 2:
			{
				System.out.println("enter id to be update");
				int id = s.nextInt();
				System.out.println("Enter Update name, email, password");
				String name = s.next();
				String email = s.next();
				String pass = s.next();
				n= u1.count() + 1;
				user = new User(n,email,pass,name);
				u1.update(user,id);
				if(n==u1.count()+1)
					System.out.println("updated successfully");
				else
					System.out.println("Updation not successfull");
				break;
			}
			case 3:
			{
				System.out.println("enter id of user fetch");
				int j = s.nextInt();
				System.out.println(u1.get(j));
				break;
				
			}
			case 4:
			{
				System.out.println("enter id of user delete");
				int j = s.nextInt();
				user = u1.delete(j);
				System.out.println("user deleted:-"+user);
				break;
			}
			case 5:
			{
				System.out.println(u1.getAll());
				break;
			}
			
			
			
			}


		}
		
	}

}
