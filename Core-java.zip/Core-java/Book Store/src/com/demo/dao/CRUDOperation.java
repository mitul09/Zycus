package com.demo.dao;

public class CRUDOperation 
{
	public static final String GET_ALL_USERS = "SELECT * FROM user";
	public static final String GET_USER_BY_ID ="SELECT * FROM user WHERE userid=?";
	public static final String CREATE_USER = "INSERT INTO user (userid,fullname,emailid,password) VALUES (?,?,?,?)";
	public static final String UPDATE_USER  = "UPDATE user SET fullname=? ,emailid =? ,password=? WHERE userid=?";
	public static final String DELETE_USER = "DELETE USER WHERE userid=?";
	
}
