package com.demo.dao;
//import java.sql.*;
import com.demo.model.User;


import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UserDAO implements USERService
{
	private SessionFactory sessionFactory;

	Map<Integer,User> um = new HashMap<>();
	public UserDAO() 
	{
		Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        this.sessionFactory =  cfg.buildSessionFactory();
	
	}

	
	public User create(User u)
	{
		
		Session session =  sessionFactory.openSession();
		
		session.beginTransaction();
		session.save(u);
		session.getTransaction().commit();	
		return um.put(u.getUserid(), u);
	}

	public User update(User u,int id)
	{	
		
		String name = u.getFullname();
		String email = u.getEmail();
		String pass = u.getPassword();

		um.replace(id, u);
		System.out.println(um.get(id));
		return u;
	}

	public User get(int userid)
	{
		
		User u1 = um.get(userid);
		return u1;
	}

	public User delete(int userid)
	{
		
		User u1 = um.get(userid);
		um.remove(userid);
		return u1;
	}

	public List<User> getAll()
	{
		List<User> l = new ArrayList<>();
		
		for (Map.Entry<Integer, User> entry : um.entrySet())
		{
			l.add(entry.getValue());
			
		}
		return l;
	}

	public int count()
	{
		return um.size();
	}

}
