package com.demo.dao;

import java.util.List;
import java.sql.*;
import com.demo.model.User;

public interface USERService 
{
	public User create(User u) throws  SQLException;
	public User update(User u,int id) throws SQLException;
	public User get(int userid) throws SQLException;
	public User delete(int userid) throws SQLException;
	public List<User> getAll() throws SQLException;
	public int count() ;




}
