import java.util.*;
class Player
{
	private String name;
	private String country;
	private String skill;
	
	public Player(String name, String country, String skill) {
		super();
		this.name = name;
		this.country = country;
		this.skill = skill;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getName() {
		return name;
	}
	public String getCountry() {
		return country;
	}
	public String getSkill() {
		return skill;
	}
	
	
}
class playerBO
{
	private String name;
	private Player player;
	Player createPlayer(String data)
	{
		String[] d= data.split(",");
		player.setName(d[0]);
		player.setCountry(d[1]);
		player.setSkill(d[2]);
		return player;
	}
	
}
class Team extends Player
{
	
	public Team(String name, String country, String skill) {
		super(name, country, skill);
		// TODO Auto-generated constructor stub
	}
	private String Tname;
	private Player player;
	
	public void setName(String Tname) {
		this.Tname = Tname;
	}
	public void setPlayer(Player player) {
		this.player = player;
	}
	
	
}
class TeamBO 
{
	
	Team T = null;
	public Team createTeam(String data, Player[] PlayerList)
	{
		String[] d= data.split(",");
		T.setName(d[0]);
		T.setCountry(d[1]);
		
	}
}
class Match
{
	private String date;
	private Team teamone;
	private Team teamtwo;
	private String venue;
	private Team team;
	
	
}
public class A17 
{
	public static void main(String []args)
	{
		
	}
}

