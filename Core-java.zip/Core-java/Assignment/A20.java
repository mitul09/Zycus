import java.util.*;
class HotelRoom
{
	protected String HName;
	protected int noofsqft;
	protected boolean hasTV;
	protected boolean hasWifi;
	
	public HotelRoom(String hName, int noofsqft, boolean hasTV, boolean hasWifi) {
		super();
		this.HName = hName;
		this.noofsqft = noofsqft;
		this.hasTV = hasTV;
		this.hasWifi = hasWifi;
	}
	
	
	
	
	public int calculateTariff(int n,int cost)
	{
		return n*cost;
	}
	public int getRatePerSqft()
	{
		return 1;
	}





	

	
}
class DeluxeRoom extends HotelRoom
{
	protected int ratepersqft;
	
	
	public DeluxeRoom(String hName, int noofsqft, boolean hasTV, boolean hasWifi, int ratepersqft) {
		super(hName, noofsqft, hasTV, hasWifi);
		this.ratepersqft = 10;
	}
	

	public int getRatePerSqft()
	{
		if(hasWifi == true)
			return this.ratepersqft+2;
		else
			return this.ratepersqft;
	}


	
	
	
	
}
class DeluxeACRoom extends DeluxeRoom
{
	protected int ratepersqft;

	public DeluxeACRoom(String hName, int noofsqft, boolean hasTV, boolean hasWifi, int ratepersqft, int ratepersqft2) {
		super(hName, noofsqft, hasTV, hasWifi, ratepersqft);
		ratepersqft = 12;
	}

	public int getRatePerSqft() {
		return ratepersqft;
	}

	
		
	
}
class SuiteACRoom extends HotelRoom
{
	private int ratepersqft;

	public SuiteACRoom(String hName, int noofsqft, boolean hasTV, boolean hasWifi, int ratePerSqft) {
		super(hName, noofsqft, hasTV, hasWifi);
		this.ratepersqft = 15;
	}
	

	public int getRatePerSqft()
	{
		if(hasWifi == true)
			return this.ratepersqft+2;
		else
			return this.ratepersqft;
	}
	
}
public class A20
{

	public static void main(String[] args) 
	{
		System.out.println("Enter details of room for final cost");
		System.out.println("1. deluxe room\n2. ACDeluxe room\n3. Suite Deluxe");
		Scanner s= new Scanner(System.in);
		int i = s.nextInt();	
		switch(i)
		{
		case 1:
			DeluxeRoom h = new DeluxeRoom("amrut",450,true,false,0);
			h.calculateTariff(450,h.getRatePerSqft());
			System.out.println(h);
		}
	}

}
