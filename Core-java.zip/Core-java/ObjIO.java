import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class Student implements Serializable {

    /**
	 * 
	 */
	String name;
    int rollno;

    public Student(String name, int rollno) {
        this.name = name;
        this.rollno = rollno;
    }
}

public class ObjIO 
{
	public static void main(String[] args) {

	        // Creates an object of Dog class
	        Student st = new Student("rahul", 32);

	        try {
	            FileOutputStream file = new FileOutputStream("file.txt");

	            // Creates an ObjectOutputStream
	            ObjectOutputStream output = new ObjectOutputStream(file);

	            // Writes objects to the output stream
	            output.writeObject(st);

	            FileInputStream fileStream = new FileInputStream("file.txt");

	            // Creates an ObjectInputStream
	            ObjectInputStream input = new ObjectInputStream(fileStream);

	            // Reads the objects
	            Student st1 = (Student) input.readObject();

	            System.out.println("Student Name: " + st1.name);
	            System.out.println("Student rollno: " + st1.rollno);

	            output.close();
	            input.close();
	        }

	        catch (Exception e) {
	            e.getStackTrace();
	        }
	    }
	}

