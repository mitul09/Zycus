import { Projects } from './projects';

describe('Projects', () => {
  it('should create an instance', () => {
    expect(new Projects()).toBeTruthy();
  });
});
