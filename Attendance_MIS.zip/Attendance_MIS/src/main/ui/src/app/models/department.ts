export class Department 
{
    
    d_id: number;
    d_name: String;
}
