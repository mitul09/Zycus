import { Task } from './task';
import { User } from './user';
export class UserTask 
{

    user_task_id: number;
    desciption: String;
    from_time: Date;
    to_time: Date;
    task: Task;
    user: User;
}
