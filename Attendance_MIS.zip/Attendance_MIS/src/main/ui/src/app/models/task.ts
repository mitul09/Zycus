import { Department } from './department';
import { Projects } from './projects';
export class Task 
{
    t_id: number;
        t_name: String;
        time_spent: number;
        project: Projects;
}
