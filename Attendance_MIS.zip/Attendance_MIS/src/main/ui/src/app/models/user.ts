import { Department } from './department';
export class User 
{
        
        u_name: String;
        u_password: String;
        d_name: String;
}
