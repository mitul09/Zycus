import { Department } from './department';

export class Projects 
{
    p_id: number;
        p_name: String;
        time_spent: number;
        department: Department;

    
}
