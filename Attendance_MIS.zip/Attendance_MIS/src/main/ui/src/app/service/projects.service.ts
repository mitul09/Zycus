import { Injectable } from '@angular/core';
import { Projects } from '../models/projects';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProjectsService 
{
  private apiEndPoint = 'http://localhost:8081/api'
  private url = this.apiEndPoint + '/projects';
  constructor(private httpclient: HttpClient) 
  {

  }
  public getAllProject(): Observable<Projects[]> {
    return this.httpclient.get<Projects[]>(this.url).pipe(
      catchError(this.handleError)
    )
  }

  public getProject(id: number): Observable<Projects>{
    return this.httpclient.get<Projects>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }
  public getProjectbydepartment(id: number): Observable<Projects[]>
  {
    return this.httpclient.get<Projects[]>(this.url + '/getprojectsbydepartmentid/' + id ).pipe(
      catchError(this.handleError)
    )
  }

  public saveProject(proj): Observable<Projects> 
  {

    if (!proj.p_id)
    {
      return this.httpclient.post<Projects>(this.url, proj).pipe(
        catchError(this.handleError)
      )
    } 
    else //if project already present
    {
      const projectToUpdate = 
      {
        p_name: proj.p_name,
        time_spent: proj.time_spent,
        department: proj.Department 
      }
      return this.httpclient.put<Projects>(this.url + '/' + proj.p_id, projectToUpdate).pipe(
        catchError(this.handleError)
      )
    }
  }
  public deleteProject(id: number): Observable<Projects> 
  {

    return this.httpclient.delete<Projects>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }  

  


  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      //client error 
      errorMessage = 'Error ' + error.error.message;
    } else {
      //server error 
      errorMessage = `Error Code : ${error.status} \n Message :  ${error.message}`
    }
    return throwError(errorMessage)
  }

}
