import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from '../models/user';
import { Department } from '../models/department';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiEndPoint = 'http://localhost:8081/api'
  private url = this.apiEndPoint + '/user';
  constructor(private httpclient: HttpClient) 
  {

  }
  public getAllUser(): Observable<User[]> {
    return this.httpclient.get<User[]>(this.url).pipe(
      catchError(this.handleError)
    )
  }

  public getUser(id: number): Observable<User>{
    return this.httpclient.get<User>(this.url+ '/' +id).pipe(
      catchError(this.handleError)
    )
  }
  public getUserbydepartment(id: number): Observable<User[]>
  {
    return this.httpclient.get<User[]>(this.url + '/getuserbydepartmentid/' + id ).pipe(
      catchError(this.handleError)
    )
  }

  public saveUser(user): Observable<User> 
  {

    if (!user.u_id)
    {
      return this.httpclient.post<User>(this.url, user).pipe(
        catchError(this.handleError)
      )
    } 
    else //if user already present
    {
      const userToUpdate = 
      {
        u_name: user.u_name,
        u_password: user.u_password,
        department: user.Department 
      }
      return this.httpclient.put<User>(this.url + '/' + user.u_id, userToUpdate).pipe(
        catchError(this.handleError)
      )
    }
  }
  public deleteUser(id: number): Observable<User> 
  {

    return this.httpclient.delete<User>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }  

  


  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      //client error 
      errorMessage = 'Error ' + error.error.message;
    } else {
      //server error 
      errorMessage = `Error Code : ${error.status} \n Message :  ${error.message}`
    }
    return throwError(errorMessage)
  }

}
