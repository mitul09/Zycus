import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from '../models/user';
import { Department } from '../models/department';
import { Task } from '../models/task';
import { UserTask } from '../models/user-task';
@Injectable({
  providedIn: 'root'
})
export class UserTaskService {

  private apiEndPoint = 'http://localhost:8081/api'
  private url = this.apiEndPoint + '/usertask';
  constructor(private httpclient: HttpClient) 
  {

  }
  public getAllUser(): Observable<UserTask[]> {
    return this.httpclient.get<UserTask[]>(this.url).pipe(
      catchError(this.handleError)
    )
  }

  public getUserTask(id: number): Observable<UserTask>{
    return this.httpclient.get<UserTask>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }
  /*
  public getUserbydepartment(id: number): Observable<UserTask[]>
  {
    return this.httpclient.get<User[]>(this.url + '/getuserbydepartmentid/' + id ).pipe(
      catchError(this.handleError)
    )
  }*/

  public saveUserTask(usertask): Observable<UserTask> 
  {

    if (!usertask.usertask_id)
    {
      return this.httpclient.post<UserTask>(this.url, usertask).pipe(
        catchError(this.handleError)
      )
    } 
    else //if project already present
    {
      const usertaskToUpdate = 
      {
        user_task_id: usertask.user_task_id,
        desciption: usertask.description,
        from_time: usertask.from_time,
        to_time: usertask.to_time,
        task: usertask.Task,
        user: usertask.User
      }
      return this.httpclient.put<UserTask>(this.url + '/' + usertask.usertask_id, usertaskToUpdate).pipe(
        catchError(this.handleError)
      )
    }
  }
  public deleteUserTask(id: number): Observable<UserTask> 
  {

    return this.httpclient.delete<UserTask>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }  

  


  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      //client error 
      errorMessage = 'Error ' + error.error.message;
    } else {
      //server error 
      errorMessage = `Error Code : ${error.status} \n Message :  ${error.message}`
    }
    return throwError(errorMessage)
  }

}
