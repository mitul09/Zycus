import { Injectable } from '@angular/core';
import { Department } from '../models/department';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DepartmentService 
{
  private apiEndPoint = 'http://localhost:8081/api'
  private url = this.apiEndPoint + '/department';
  constructor(private httpclient: HttpClient)
  {
  
  }
  public getAllDepartment(): Observable<Department[]> {
    return this.httpclient.get<Department[]>(this.url).pipe(
      catchError(this.handleError)
    )
  }

  public getDepartment(id: number): Observable<Department>{
    return this.httpclient.get<Department>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }

  public saveDepartment(dept): Observable<Department> 
  {

    if (!dept.d_id)
    {
      return this.httpclient.post<Department>(this.url, dept).pipe(
        catchError(this.handleError)
      )
    } 
    else //if department already present
    {
      const departmentToUpdate = {
        d_name: dept.d_name,
      }
      return this.httpclient.put<Department>(this.url + '/' + dept.d_id, departmentToUpdate).pipe(
        catchError(this.handleError)
      )
    }
  }
  public deleteDepartment(id: number): Observable<Department> 
  {

    return this.httpclient.delete<Department>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }  

  


  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      //client error 
      errorMessage = 'Error ' + error.error.message;
    } else {
      //server error 
      errorMessage = `Error Code : ${error.status} \n Message :  ${error.message}`
    }
    return throwError(errorMessage)
  }

}
