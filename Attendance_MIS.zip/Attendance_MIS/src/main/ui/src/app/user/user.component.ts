import { Component, OnInit } from '@angular/core';
import { ProjectsService } from '../service/projects.service';
import { Projects } from '../models/projects';
import { Observable } from 'rxjs';
import { FormBuilder, FormGroup } from '@angular/forms';
import { UserService } from '../service/user.service';
import { User } from '../models/user';
import { FormsModule } from '@angular/forms';
import { Department } from '../models/department';
import { DepartmentService } from '../service/department.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {


  constructor() {
    
  }
  public projectList: any[];
  public errMessage: string;
  public hasError:boolean = false;
  public userservice: UserService;
  public department: Department;
  public departmentservice: DepartmentService;
  // public user: UserService["getUser"];
  
  
  
  ngOnInit(): void 
  {
    
  }
  
  

}
