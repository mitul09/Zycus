import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addusertask',
  templateUrl: './addusertask.component.html',
  styleUrls: ['./addusertask.component.css']
})
export class AddusertaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
