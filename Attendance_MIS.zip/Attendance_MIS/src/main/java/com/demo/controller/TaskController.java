package com.demo.controller;


import java.util.*;

import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.service.*;
import com.demo.entities.*;

@RestController
@RequestMapping(path = "/api/task")
public class TaskController 
{
	@Autowired
	TaskService taskservice;
	
	
	@GetMapping(path=("/gettaskbyprojectid/{t_id}"))
	public List<Task> findTask(@PathVariable("t_id") Long id)
	{
		return this.taskservice.findTask(id);
	}
	@GetMapping(path ="")
	public List<Task> getAllTask()
	{
		return this.taskservice.getAllTask();
	}
	
	@GetMapping(path = "{t_id}")
	public Task getTask(@PathVariable("t_id") Long id)
	{
		return this.taskservice.getTask(id);
	}
	
	
	@PostMapping(path = "")
	public Task createTask( @RequestBody  Task task) 
	{
		
		return this.taskservice.save(task);
	}	
	@DeleteMapping(path = "/{t_id}")
	public Task delete(@PathVariable("t_id") Long id) {
		return this.taskservice.remove(id);
	}
	
	@PutMapping(path = "/{t_id}")
	public ResponseEntity<Task> updateTask(@PathVariable("t_id") Long id,  @RequestBody Task task) throws ValidationException {
		
		Task t = this.taskservice.getTask(id);
		
		if(t!=null) {
			t=  this.taskservice.save(task);
			return new ResponseEntity<Task>(t, HttpStatus.OK);
		}
		else {
			throw new ValidationException("task_id not found");
		}

	}
}
