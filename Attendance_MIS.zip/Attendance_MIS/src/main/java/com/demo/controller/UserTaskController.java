package com.demo.controller;
import java.util.List;

import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.demo.entities.*;
import com.demo.service.*;
import com.fasterxml.jackson.annotation.JsonFormat;
@RestController
@RequestMapping(path = "/api/usertask")
public class UserTaskController 
{
	@Autowired
	UserTaskService usertaskservice;
	
	@GetMapping(path ="")
	public List<UserTask> getAllUserTask()
	{
		return this.usertaskservice.getAllUserTask();
	}
	
	@GetMapping(path = "{usertask_id}")
	public UserTask getUserTask(@PathVariable("usertask_id") Long id)
	{
		return this.usertaskservice.getUserTask(id);
	}
	
	
	@PostMapping(path = "")
	//@JsonFormat(shape=JsonFormat.Shape.ARRAY)
	public UserTask createUserTask( @RequestBody  UserTask user) 
	{
		
		return this.usertaskservice.save(user);
	}	
	@DeleteMapping(path = "/{usertask_id}")
	public UserTask delete(@PathVariable("usertask_id") Long id) {
		return this.usertaskservice.remove(id);
	}
	
	@PutMapping(path = "/{usertask_id}")
	//@JsonFormat(shape=JsonFormat.Shape.ARRAY)
	public ResponseEntity<UserTask> updateUserTask(@PathVariable("usertask_id") Long id,  @RequestBody UserTask user) throws ValidationException {
		
		UserTask u = this.usertaskservice.getUserTask(id);
		
		if(u!=null) {
			u=  this.usertaskservice.save(user);
			return new ResponseEntity<UserTask>(u, HttpStatus.OK);
		}
		else {
			throw new ValidationException("user_id not found");
		}

	}
}
