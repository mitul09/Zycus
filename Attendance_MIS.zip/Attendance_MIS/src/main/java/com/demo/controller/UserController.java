package com.demo.controller;

import java.util.List;

import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.demo.entities.*;
import com.demo.service.ProjectsService;
import com.demo.service.UserService;
@RestController
@RequestMapping(path = "/api/user")
public class UserController 
{
	@Autowired
	UserService userservice;
	
	@GetMapping(path=("/getuserbydepartmentname/{d_name}"))
	public List<User> findUser(@PathVariable("d_name") String d_name)
	{
		return this.userservice.findUser(d_name);
	}
	
	@GetMapping(path ="")
	public List<User> getAllUser()
	{
		return this.userservice.getAllUser();
	}
	
	@GetMapping(path = "{u_id}")
	public User getUser(@PathVariable("u_id") Long id)
	{
		return this.userservice.getUser(id);
	}
	
	
	@PostMapping(path = "")
	public User createUser( @RequestBody  User user) 
	{
		
		return this.userservice.save(user);
	}	
	@DeleteMapping(path = "/{u_id}")
	public User delete(@PathVariable("u_id") Long id) {
		return this.userservice.remove(id);
	}
	
	@PutMapping(path = "/{u_id}")
	public ResponseEntity<User> updateUser(@PathVariable("u_id") Long id,  @RequestBody User user) throws ValidationException {
		
		User u = this.userservice.getUser(id);
		
		if(u!=null) {
			u=  this.userservice.save(user);
			return new ResponseEntity<User>(u, HttpStatus.OK);
		}
		else {
			throw new ValidationException("user_id not found");
		}

	}
}
