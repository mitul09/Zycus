package com.demo.controller;
import java.util.*;

import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.service.DepartmentService;
import com.demo.service.ProjectsService;
import com.demo.entities.*;
@RestController
@RequestMapping(path = "/api/projects")
public class ProjectController 
{
	@Autowired
	ProjectsService projectservice;
	
	@GetMapping(path=("/getprojectsbydepartmentname/{d_id}"))
	public List<Projects> findProjects(@PathVariable("d_id") Long d_id)
	{
		return this.projectservice.findProjects(d_id);
	}
	
	
	@GetMapping(path ="")
	public List<Projects> getAllProject()
	{
		return this.projectservice.getAllProject();
	}
	
	@GetMapping(path = "{p_id}")
	public Projects getProject(@PathVariable("p_id") Long id)
	{
		return this.projectservice.getProject(id);
	}
	
	
	@PostMapping(path = "")
	public ResponseEntity<Projects> createProject( @RequestBody  Projects proj) 
	{
		
		Projects p = this.projectservice.save(proj);
		if(getProject(p.getP_id())!=proj)
			return new ResponseEntity<Projects>(p,HttpStatus.OK);
		else
			return new ResponseEntity<Projects>(p,HttpStatus.NOT_ACCEPTABLE);
	}	
	@DeleteMapping(path = "/{p_id}")
	public ResponseEntity<Projects> delete(@PathVariable("p_id") Long id) {
		Projects p =  this.projectservice.remove(id);
		if(getProject(p.getP_id())==null)
			return new ResponseEntity<Projects>(p,HttpStatus.OK);
		else
			return new ResponseEntity<Projects>(p,HttpStatus.NOT_FOUND);
	}
	
	@PutMapping(path = "/{p_id}")
	public ResponseEntity<Projects> updateProjects(@PathVariable("p_id") Long id,  @RequestBody Projects proj) throws ValidationException {
		
		Projects p = this.projectservice.getProject(id);
		
		if(p!=null) {
			p=  this.projectservice.save(proj);
			return new ResponseEntity<Projects>(p, HttpStatus.OK);
		}
		else {
			throw new ValidationException("proj_id not found");
		}

	}
}
