package com.demo.controller;

import java.util.*;

import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.service.DepartmentService;
import com.demo.entities.*;
@RestController
@RequestMapping(path = "/api/department")
public class DepartmentController 
{
	@Autowired
	DepartmentService departmentservice;
	
	@GetMapping(path ="")
	public List<Department> getAllDepartment()
	{
		return this.departmentservice.getAllDepartment();
	}
	
	@GetMapping(path = "{d_id}")
	public Department getDepartment(@PathVariable("d_id") Long id)
	{
		return this.departmentservice.getDepartment(id);
	}
	
	
	@PostMapping(path = "")
	public Department createDepartment( @RequestBody  Department dept) 
	{
		System.out.println("controller"+dept);
		return this.departmentservice.save(dept);
	}	
	@DeleteMapping(path = "/{d_id}")
	public Department delete(@PathVariable("d_id") Long id) {
		return this.departmentservice.remove(id);
	}
	
	@PutMapping(path = "/{d_id}")
	public ResponseEntity<Department> updateDepartment(@PathVariable("d_id") Long id,  @RequestBody Department dept) throws ValidationException {
		
		Department d = this.departmentservice.getDepartment(id);
		
		if(d!=null) {
			d=  this.departmentservice.save(dept);
			return new ResponseEntity<Department>(d, HttpStatus.OK);
		}
		else {
			throw new ValidationException("dept_id not found");
		}

	}
}
