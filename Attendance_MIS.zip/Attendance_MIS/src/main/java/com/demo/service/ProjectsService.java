package com.demo.service;
import java.util.*;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.Projects;
import com.demo.repositories.ProjectsRepository;


@Service
@Transactional
public class ProjectsService
{
	@Autowired
	ProjectsRepository projectrepository;
	
	
	
	public List<Projects> findProjects(Long d_id)
	{
		return projectrepository.findProjects(d_id);
	}
	public Projects save(Projects p)
	{
		Projects proj= null;
		
		if(p.getP_id() == null) {
			proj = projectrepository.save(p);
		}else {
			proj = getProject(p.getP_id());
			if(proj!=null) 
			{
				proj.setP_id(p.getP_id());
				proj.setP_name(p.getP_name());
				proj.setD(p.getD());
				proj.setTime_spent(p.getTime_spent());
			}
		}
		
		return proj;
	}
	public Projects getProject(Long id)
	{
		Optional<Projects> optProject =  projectrepository.findById(id);
		Projects p = null;
		if(optProject.isPresent())
			p = optProject.get();
		
		return p;
	}
	
	public List<Projects> getAllProject(){
		return projectrepository.findAll();
	}
	public Projects remove(Long id) {
		Projects p = getProject(id);
		if(p!=null) {
			projectrepository.delete(p);
		}
		return p;
	}
}
