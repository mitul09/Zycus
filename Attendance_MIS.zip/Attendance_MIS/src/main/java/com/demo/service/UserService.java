package com.demo.service;

import java.util.*;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.*;
import com.demo.repositories.*;


@Service
@Transactional
public class UserService 
{
	@Autowired
	UserRepository userrepository;
	
	public List<User> findUser(Long d_id)
	{
		return userrepository.findUser(d_id);
	}
	public User save(User u)
	{
		User user= null;
		
		if(u.getU_id() == null) {
			user = userrepository.save(u);
		}else {
			user = getUser(u.getU_id());
			if(user!=null) 
			{
				user.setU_id(u.getU_id());
				user.setU_name(u.getU_name());
				user.setU_password(u.getU_password());
				user.setD(u.getD());
			}
		}
		
		return user;
	}
	public User getUser(Long id)
	{
		Optional<User> optUser =  userrepository.findById(id);
		User u = null;
		if(optUser.isPresent())
			u = optUser.get();
		
		return u;
	}
	
	public List<User> getAllUser(){
		return userrepository.findAll();
	}
	public User remove(Long id) {
		User u = getUser(id);
		if(u!=null) {
			userrepository.delete(u);
		}
		return u;
	}
}
