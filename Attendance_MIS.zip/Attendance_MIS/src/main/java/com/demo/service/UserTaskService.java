package com.demo.service;
import java.sql.*;
import java.util.*;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.*;
import com.demo.repositories.*;
@Service
@Transactional
public class UserTaskService
{
	@Autowired
	UserTaskRepository usertaskrepository;
	
	@Autowired
	TaskService taskservice;
	@Autowired
	ProjectsService projectservice;
	
	public UserTask save(UserTask u)
	{
		UserTask user= null;
		
		if(u.getUserTask_id() != null) {
			user = usertaskrepository.save(u);
		}else {
			user = getUserTask(u.getUserTask_id());
			if(user!=null) 
			{
				user.setUserTask_id(u.getUserTask_id());
				user.setDescription(u.getDescription());
				user.setFrom_t(u.getFrom_t());
				user.setTo_t(u.getTo_t());
				//user.setP(u.getP());
				user.setU(u.getU());
				user.setT(u.getT());
				//Timestamp a = u.getFrom_t();
				//Timestamp b = u.getTo_t();
				//Long l = b.getTime()-a.getTime();
				user.setTotal_time(u.getTotal_time());
				
			}
		}
		Long t = user.getTotal_time();
		
		
		//finding task
		Task task = taskservice.getTask(user.getT().getT_id());
		//updating that task with time
		task.setTime_spent(task.getTime_spent()+t);
		taskservice.save(task);
		return user;
	}
	public UserTask getUserTask(Long id)
	{
		Optional<UserTask> optUser =  usertaskrepository.findById(id);
		UserTask u = null;
		if(optUser.isPresent())
			u = optUser.get();
		
		return u;
	}
	
	public List<UserTask> getAllUserTask(){
		return usertaskrepository.findAll();
	}
	public UserTask remove(Long id) {
		UserTask u = getUserTask(id);
		if(u!=null) {
			usertaskrepository.delete(u);
		}
		return u;
	}
}
