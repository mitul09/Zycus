package com.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.entities.*;
import com.demo.repositories.*;
@Service
@Transactional
public class TaskService
{
	@Autowired
	TaskRepository taskrepository;
	

	public List<Task> findTask(Long p_id)
	{
		return taskrepository.findTask(p_id);
	}
	public Task save(Task t)
	{
		Task task= null;
		
		if(t.getT_id() == null) {
			task = taskrepository.save(t);
		}else {
			task = getTask(t.getT_id());
			if(task!=null) 
			{
				task.setT_id(t.getT_id());
				task.setT_name(t.getT_name());
				task.setTime_spent(t.getTime_spent());
				task.setP(t.getP());
			}
		}
		
		return task;
	}

	public Task getTask(Long id)
	{
		Optional<Task> optTask =  taskrepository.findById(id);
		Task t= null;
		if(optTask.isPresent())
			t = optTask.get();
		
		return t;
	}
	

	public List<Task> getAllTask(){
		return taskrepository.findAll();
	}
	public Task remove(Long id) {
		Task t = getTask(id);
		if(t!=null) {
			taskrepository.delete(t);
		}
		return t;
	}
	
}
