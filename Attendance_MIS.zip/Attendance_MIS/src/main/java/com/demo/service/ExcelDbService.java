package com.demo.service;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileOutputStream;

import java.sql.*;

public class ExcelDbService 
{
	
	public void downloadExcel(Object obj) throws SQLException
	{
		 try 
		 {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager.getConnection( 
				     "jdbc:mysql://localhost:3306/newdb" , 
				     "mitul" , 
				     "M!tul9966"
				  );
			Statement stmt = connect.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from ?");
			
		 } 
		 catch (ClassNotFoundException e)
		 {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }
		 
	      

	}
}
