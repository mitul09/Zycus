package com.demo.service;

import java.util.*;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.Department;
import com.demo.repositories.DepartmentRepository;

@Service
@Transactional
public class DepartmentService 
{
	@Autowired
	DepartmentRepository departmentrepository;
	
	public Department save(Department d)
	{
		Department dept= null;
		System.out.println("Service 1"+d);
		if(d.getD_id() == null) 
		{
			dept = departmentrepository.save(d);
			
		}else {
			dept = getDepartment(d.getD_id());
			System.out.println("department"+dept);
			if(dept!=null) 
			{
				dept.setD_id(d.getD_id());
				dept.setD_name(d.getD_name());
				
			}
		}
		System.out.println("service 2"+dept);
		return dept;
	}
	public Department getDepartment(Long id)
	{
		Optional<Department> optDepartment =  departmentrepository.findById(id);
		Department d = null;
		if(optDepartment.isPresent())
			d = optDepartment.get();
		
		return d;
	}
	
	public List<Department> getAllDepartment(){
		return departmentrepository.findAll();
	}
	public Department remove(Long id) {
		Department d = getDepartment(id);
		if(d!=null) {
			departmentrepository.delete(d);
		}
		return d;
	}

}
