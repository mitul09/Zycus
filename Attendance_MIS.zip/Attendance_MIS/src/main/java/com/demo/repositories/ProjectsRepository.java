package com.demo.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.demo.entities.Projects;
//@RepositoryRestResource
public interface ProjectsRepository extends JpaRepository<Projects, Long>
{
	@Query(value = "select * from projects  where d_id=:d_id",nativeQuery=true)
	List<Projects> findProjects(@Param("d_id") Long d_id);

}
