package com.demo.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
//import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.demo.entities.*;

@RepositoryRestResource
public interface TaskRepository  extends JpaRepository<Task, Long>
{
	@Query(value = "select * from task  where p_id=:p_id",nativeQuery=true)
	List<Task> findTask(@Param("p_id") Long p_id);

}
