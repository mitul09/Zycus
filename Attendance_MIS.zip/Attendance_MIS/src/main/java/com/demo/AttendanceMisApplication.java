package com.demo;

//import org.springframework.boot.CommandLineRunner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import com.demo.service.*;
//import com.demo.entities.*;
@SpringBootApplication
public class AttendanceMisApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendanceMisApplication.class, args);
		
	}
	

	
}
