package com.demo.entities;
import java.util.*;
import javax.persistence.*;

import com.demo.entities.*;


@Entity
public class Projects 
{
	@Id
	private Long p_id;
	private String p_name;
	//private Long total_task;
	private Double time_spent=0D;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="d_id")
	private Department d= null;

	public Projects() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Projects(Long p_id, String p_name, Double time_spent, Department d) {
		super();
		this.p_id = p_id;
		this.p_name = p_name;
		this.time_spent = time_spent;
		this.d = d;
	}

	public Long getP_id() {
		return p_id;
	}

	public void setP_id(Long p_id) {
		this.p_id = p_id;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public Double getTime_spent() {
		return time_spent;
	}

	public void setTime_spent(Double time_spent) {
		this.time_spent = time_spent;
	}

	public Department getD() {
		return d;
	}

	public void setD(Department d) {
		this.d = d;
	}

	@Override
	public String toString() {
		return "Projects [p_id=" + p_id + ", p_name=" + p_name + ", time_spent=" + time_spent + ", d=" + d + "]";
	}
	
	
	
	

	

	

}
