package com.demo.entities;

import java.util.*;
import javax.persistence.*;
import com.demo.entities.*;
@Entity
public class Department 
{
	@Id
	@Column(name="d_id")
	private Long d_id;
	private String d_name;

	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Department(Long d_id, String d_name) {
		super();
		this.d_id = d_id;
		this.d_name = d_name;
	}


	public Long getD_id() {
		return d_id;
	}

	public void setD_id(Long d_id) {
		this.d_id = d_id;
	}

	public String getD_name() {
		return d_name;
	}

	public void setD_name(String d_name) {
		this.d_name = d_name;
	}

	


	@Override
	public String toString() {
		return "Department [d_id=" + d_id + ", d_name=" + d_name + "]";
	}

	
	
	
	
}
