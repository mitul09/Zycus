package com.demo.entities;
import com.demo.entities.Projects;

import javax.persistence.*;


@Entity
public class Task 
{
	@Id
	private Long t_id;
	private String t_name;
	private Double time_spent=0D;
	
	
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="p_id")
	private Projects p;



	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}



	



	public Task(Long t_id, String t_name, Double time_spent, Projects p) {
		super();
		this.t_id = t_id;
		this.t_name = t_name;
		this.time_spent = time_spent;
		this.p = p;
	}







	public Long getT_id() {
		return t_id;
	}



	public void setT_id(Long t_id) {
		this.t_id = t_id;
	}



	public String getT_name() {
		return t_name;
	}



	public void setT_name(String t_name) {
		this.t_name = t_name;
	}



	public Double getTime_spent() {
		return time_spent;
	}



	public void setTime_spent(Double time_spent) {
		this.time_spent = time_spent;
	}



	public Projects getP() {
		return p;
	}



	public void setP(Projects p) {
		this.p = p;
	}



	@Override
	public String toString() {
		return "Task [t_id=" + t_id + ", t_name=" + t_name + ", time_spent=" + time_spent + ", p=" + p + "]";
	}
	
	
}
