package com.demo.entities;
import java.sql.*;

import javax.persistence.*;

@Entity
public class UserTask 
{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long UserTask_id;
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="t_id")
	private Task t;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="u_id")
	private User u;
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="p_id")
	private Projects p;
	private String description;
	private Timestamp from_t=null;
	private Timestamp to_t=null;
	
	private Long total_time;
	public UserTask() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public UserTask(Long userTask_id, Task t, User u, Projects p, String description, Timestamp from_t, Timestamp to_t,
			Long total_time) {
		super();
		this.UserTask_id = userTask_id;
		this.t = t;
		this.u = u;
		this.p = p;
		this.description = description;
		this.from_t = from_t;
		this.to_t = to_t;
		this.total_time = from_t.getTime()-to_t.getTime();
	}





	public Long getTotal_time() {
		return total_time;
	}



	public void setTotal_time(Long total_time) 
	{
		//Long l = this.from_t.getTime()-this.to_t.getTime();
		this.total_time = total_time;
	}



	public Long getUserTask_id() {
		return UserTask_id;
	}

	public void setUserTask_id(Long userTask_id) {
		UserTask_id = userTask_id;
	}

	public Task getT() {
		return t;
	}

	public void setT(Task t) {
		this.t = t;
	}

	public User getU() {
		return u;
	}

	public void setU(User u) {
		this.u = u;
	}

	public Projects getP() {
		return p;
	}

	public void setP(Projects p) {
		this.p = p;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getFrom_t() {
		return from_t;
	}

	public void setFrom_t(Timestamp from_t) {
		this.from_t = from_t;
	}

	public Timestamp getTo_t() {
		return to_t;
	}

	public void setTo_t(Timestamp to_t) {
		this.to_t = to_t;
	}



	@Override
	public String toString() {
		return "UserTask [UserTask_id=" + UserTask_id + ", t=" + t + ", u=" + u + ", p=" + p + ", description="
				+ description + ", from_t=" + from_t + ", to_t=" + to_t + ", total_time=" + total_time + "]";
	}

	
		
	
	
}
