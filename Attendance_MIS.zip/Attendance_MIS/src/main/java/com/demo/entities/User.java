package com.demo.entities;
import javax.persistence.*;

import com.demo.entities.*;

@Entity
public class User
{
	@Id
	private Long u_id;
	private String u_name;
	private String u_password;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "d_id")
	private Department d;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(Long u_id, String u_name, String u_password, Department d) {
		super();
		this.u_id = u_id;
		this.u_name = u_name;
		this.u_password = u_password;
		this.d = d;
	}

	public Long getU_id() {
		return u_id;
	}

	public void setU_id(Long u_id) {
		this.u_id = u_id;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getU_password() {
		return u_password;
	}

	public void setU_password(String u_password) {
		this.u_password = u_password;
	}

	public Department getD() {
		return d;
	}

	public void setD(Department d) {
		this.d = d;
	}

	@Override
	public String toString() {
		return "User [u_id=" + u_id + ", u_name=" + u_name + ", u_password=" + u_password + ", d=" + d + "]";
	}
	
	
	
}
