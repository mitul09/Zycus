package com.demo.entities;
import javax.persistence.*;

import com.demo.entities.*;

@Entity
public class User
{
	@Id
	private Long u_id;
	private String u_name;
	private String u_password;
	private String d_name;
	

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(Long u_id, String u_name, String u_password, String d_name) {
		super();
		this.u_id = u_id;
		this.u_name = u_name;
		this.u_password = u_password;
		this.d_name = d_name;
	}

	public Long getU_id() {
		return u_id;
	}

	public void setU_id(Long u_id) {
		this.u_id = u_id;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getU_password() {
		return u_password;
	}

	public void setU_password(String u_password) {
		this.u_password = u_password;
	}

	public String getD_id() {
		return d_name;
	}

	public void setD_id(String d_name) {
		this.d_name = d_name;
	}

	@Override
	public String toString() {
		return "User [u_id=" + u_id + ", u_name=" + u_name + ", u_password=" + u_password + ", d_name=" + d_name + "]";
	}

	

	
	
}
