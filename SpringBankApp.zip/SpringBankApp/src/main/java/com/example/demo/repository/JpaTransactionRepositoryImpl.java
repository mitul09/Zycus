package com.example.demo.repository;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entities.TransactionDetail;

@Repository("jpa-transact")
@Component("jpa-transact")
public class JpaTransactionRepositoryImpl implements TransactionRepository {

	
	@PersistenceContext
	private EntityManager em;
	
	@Override
	@Transactional
	public Long addTransaction(TransactionDetail transactionDetail) throws SQLException {
		// TODO Auto-generated method stub
		//	em.getTransaction().begin();
		em.persist(transactionDetail);
	//	em.getTransaction().commit();
		return transactionDetail.getAccountNumber();
	}

	@Override
	@Transactional
	public List<TransactionDetail> getAllTransactionDetailsByAccountNumber(Long accountNumber) throws SQLException {
		// TODO Auto-generated method stub
		Query query = em.createQuery("Select a from TransactionDetail a where a.transactionId=? :id",TransactionDetail.class);
		query.setParameter("id",accountNumber);
		
		
		return query.getResultList();
	}

}
