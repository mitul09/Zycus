package javadb;
import java.sql.*;
import java.util.*;
public class EmployeeDAO
{
	public Employee createEmployee(int id,String name, int salary,String location)
	{
		Connection conn = DBconnect.getConnection();
		if(conn!= null)
		{
			PreparedStatement stmt;
			try {
				stmt = conn.prepareStatement(EmployeeCRUD.ADD_EMPLOYEE);

				stmt.setInt(1, id);
				stmt.setString(2, name);
				stmt.setInt(3, salary);
				stmt.setString(4, location);
				int result = stmt.executeUpdate();
				if(result>0)
				{
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return null;
	}
	public Employee getEmployeeById(int id)
	{
		Connection conn = DBconnect.getConnection();
		if(conn!=null)
		{
			PreparedStatement stmt;
			try 
			{
				stmt = conn.prepareStatement(EmployeeCRUD.GET_EMPLOYEE_BY_ID);
				stmt.setInt(1, id);
				ResultSet rs = stmt.executeQuery();
				rs.next();
				int empid = rs.getInt("emp_id");
				String ename = rs.getString("emp_name");
				String city = rs.getString("emp_location");
				int salary = rs.getInt("emp_salary");
				
				
				Employee emp = new Employee(empid,ename,city,salary);
				DBconnect.closeConnection(conn);
				return emp;
			}
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	public List<Employee> getEmployees()
	{
		Connection conn = DBconnect.getConnection();
		List<Employee> list = new ArrayList<>();
		if(conn!=null)
		{
			try 
			{
				PreparedStatement stmt = conn.prepareStatement(EmployeeCRUD.GET_ALL_EMPLOYEES);

				ResultSet rs  = stmt.executeQuery();
				
				
					while(rs.next())
					{
						
						int empid = rs.getInt("emp_id");
						String ename = rs.getString("emp_name");
						String city = rs.getString("emp_location");
						int salary = rs.getInt("emp_salary");
						Employee emp = new Employee(empid,ename,city,salary);
						list.add(emp);
					}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		DBconnect.closeConnection(conn);
		return list;
	}
}
