package javadb;

public class EmployeeCRUD 
{
	public static final String GET_ALL_EMPLOYEES = "SELECT * FROM employee ";
	public static final String GET_EMPLOYEE_BY_ID = "SELECT * FROM employee WHERE emp_id=?";
	public static final String ADD_EMPLOYEE = "INSERT INTO employee(emp_id,emp_name,emp_salary,emp_location) VALUES (?,?,?,?)";
	public static final String DELETE_EMPLOYEE = "DELETE FROM employee WHERE emp_id =? ";
	public static final String UPDATE_EMPLOYEE =  "update employee set emp_name =? , emp_salary =?, emp_location =? where emp_id =?";

}
