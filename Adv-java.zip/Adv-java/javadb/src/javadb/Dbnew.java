package javadb;
import java.util.*;
import java.sql.*;  
public class Dbnew
{  
	public static void main(String args[]) throws SQLException
	{
		List<Employee> l = new ArrayList<>();
		Scanner s = new Scanner(System.in);
		int i=0;
		while(i!=6)
		{
			System.out.println("Menu:-\n1.Add\n2.Update\n3.Delete\n4.view by id\n5.view all\n6.exit");
			i = s.nextInt();
			switch(i)
			{
				case 1:
				{
					System.out.println("enter id,name,salary,location");
					String d = s.next();
					String[] d1 = d.split(",");
					int id = Integer.parseInt(d1[0]);
					String name = d1[1];
					int salary = Integer.parseInt(d1[2]);
					String location = d1[3];
					
					try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/newdb", "mitul", "M!tul9966")) {

						Class.forName("com.mysql.cj.jdbc.Driver");
						String sql = "INSERT INTO employee(emp_id,emp_name,emp_salary,emp_location) VALUES (?,?,?,?)";
						

						
						PreparedStatement stmt = con.prepareStatement(sql);
						
						//ResultSet rs  = stmt.executeQuery();
						stmt.setInt(1, id);
						stmt.setString(2, name);
						stmt.setInt(3, salary);
						stmt.setString(4, location);
						int result = stmt.executeUpdate();
			
						if(result>0)
						{
							System.out.println("Successfully inserted data");
							Employee emp = new Employee(id,name,location,salary);
							l.add(emp);
						}
						else
							System.out.println("error");
						con.close();
						
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				}
				case 2:
				{
					System.out.println("enter id to update");
					int id= s.nextInt();
					System.out.println("enter name,salary,location");
					String d = s.next();
					String[] d1 = d.split(",");
					String name = d1[0];
					int salary  = Integer.parseInt(d1[1]);
					String location = d1[2];

					try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/newdb", "mitul", "M!tul9966"))
					{

						Class.forName("com.mysql.cj.jdbc.Driver");
						String sql = "update employee set emp_name =? , emp_salary =?, emp_location =? where emp_id =?";
						PreparedStatement stmt = con.prepareStatement(sql);
						
						//ResultSet rs  = stmt.executeQuery();
			
						stmt.setString(1, name);
						stmt.setInt(2, salary);
						stmt.setString(3, location);
						stmt.setInt(4, id);
						int result = stmt.executeUpdate();
						if(result>0)
						{
							System.out.println("Successfully updated data");
						//	Employee emp = null;
							for(Employee emp : l)
							{
								if(emp.getId() == id)
								{
									emp.setName(name);
									emp.setSalary(salary);
									emp.setLocation(location);
									
								}
							}
						}
						else
							System.out.println("error");
						con.close();
						
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					
					
					}
					
					break;
				}
				case 3:
				{
					System.out.println("enter id to delete");
					int id = s.nextInt();
					try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/newdb", "mitul", "M!tul9966"))
					{

						Class.forName("com.mysql.cj.jdbc.Driver");
						
						String sql = "DELETE FROM employee WHERE emp_id = ?";
						
						PreparedStatement stmt = con.prepareStatement(sql);
						stmt.setInt(1, id);
						//ResultSet rs  = stmt.executeQuery();
			
						int result = stmt.executeUpdate();
						if(result>0)
						{
							System.out.println("Successfully delete data");
						//	Employee emp = null;
							for(Employee emp : l)
							{
								if(emp.getId() == id)
								{
									l.remove(emp);
									
								}
							}
						}
						else
							System.out.println("error");
						con.close();
						
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					
					
				}
					break;
				}
				case 4:
				{
					System.out.println("enter id to be viewed");
					int id = s.nextInt();
					try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/newdb", "mitul", "M!tul9966"))
					{

						Class.forName("com.mysql.cj.jdbc.Driver");
						
						String sql = "SELECT * FROM employee WHERE emp_id =? ";
						
						PreparedStatement stmt = con.prepareStatement(sql);
						stmt.setInt(1, id);
			
						ResultSet rs  = stmt.executeQuery();
						rs.next();
						int j = rs.getInt("emp_id");
						String name = rs.getString("emp_name");
						String location = rs.getString("emp_location");
						int salary = rs.getInt("emp_salary");
						System.out.println(" id:- "+j+" name= "+name+" salary:- "+salary+" location:- "+location);
						con.close();
						
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					
					
				}
					break;
					
				}
				case 5:
				{
					try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/newdb", "mitul", "M!tul9966")) 
					{

						Class.forName("com.mysql.cj.jdbc.Driver");

						String sql = "SELECT * FROM employee";
						
						PreparedStatement stmt = con.prepareStatement(sql);
						
						ResultSet rs  = stmt.executeQuery();
						
						
							while(rs.next()) {
								
								int empid = rs.getInt("emp_id");
								String ename = rs.getString("emp_name");
								String city = rs.getString("emp_location");
								int salary = rs.getInt("emp_salary");
								System.out.println(" id:- "+empid+" name= "+ename+" salary:- "+salary+" location:- "+city);

							}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
	}
	}
	}
}