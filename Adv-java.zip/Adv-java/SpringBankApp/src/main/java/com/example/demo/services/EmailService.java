package com.example.demo.services;

public interface EmailService {
	
	public void sendMail(String toAddress,String fromAddress,String  content);

}
