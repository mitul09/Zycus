package com.example.demo.repository;


import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Reward;

@Repository("jpa-reward")
@Component("jpa-reward")
public class JpaRewardRepositoryImpl implements RewardRepository{

	@PersistenceContext
	private EntityManager em;

	@Override
	@Transactional
	public void addReward(Reward reward) throws SQLException {
		// TODO Auto-generated method stub
		if(reward!=null)
			em.persist(reward);
		
	}

	@Override
	@Transactional
	public int getTotalRewardAmount(Long accountNumber) throws SQLException {
		// TODO Auto-generated method stub
		List<Reward> reward = (List<Reward>) em.find(Reward.class, accountNumber);
		int total=0;
		for(Reward r: reward)
		{
			total = r.getRewardAmount() + total;
		}
		return total;
	
	}

	@Override
	@Transactional
	public List<Reward> getAllRewardsForAccount(Long accountNumber) throws SQLException {
		// TODO Auto-generated method stub
		List<Reward> reward = (List<Reward>) em.find(Reward.class, accountNumber);
		
		return reward;
	}
	
	
}
