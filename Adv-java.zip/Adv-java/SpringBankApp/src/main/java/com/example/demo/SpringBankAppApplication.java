package com.example.demo;

import java.sql.SQLException;
import java.util.*;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.demo.entities.Account;
import com.example.demo.entities.Reward;
import com.example.demo.repository.JpaRewardRepositoryImpl;
import com.example.demo.repository.RewardRepository;
import com.example.demo.services.BankService;

@SpringBootApplication
public class SpringBankAppApplication {

	public static void main(String[] args) throws SQLException {
		ApplicationContext context = SpringApplication.run(SpringBankAppApplication.class, args);
		BankService service = context.getBean(BankService.class);
		
		//List<Account> account = new ArrayList<Account>(); 
		Account account = new Account("mitul", true, 4000, "mitul@zk.com","mumbai", "india");
		service.createNewAccount(account);
		account =  new Account("akash", true, 2000, "akash@zk.com", "Pune", "india");
		service.createNewAccount(account);
		System.out.println(service.getAllAccounts());
		service.transfer(1L, 2L, 300);
		service.deActivateAccount(account.getAccountNumber());
		System.out.println(service.getAllAccounts());
		Reward reward = new Reward();
		reward.setAccountNumber(2L);
		reward.setRewardAmount(100);
		reward.setRewardConfirmationNumber(111L);
		
		RewardRepository r = context.getBean(JpaRewardRepositoryImpl.class);
		r.addReward(reward);
		reward.setAccountNumber(2L);
		reward.setRewardAmount(220);
		reward.setRewardConfirmationNumber(231L);
		
		
		System.out.println(r.getTotalRewardAmount(2L));
		System.out.println(r.getAllRewardsForAccount(2L));		
		
	}

}
