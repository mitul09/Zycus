package com.demo.service;

public interface EmailService {
	
	public void sendMail(String toAddress,String fromAddress,String  content);

}
