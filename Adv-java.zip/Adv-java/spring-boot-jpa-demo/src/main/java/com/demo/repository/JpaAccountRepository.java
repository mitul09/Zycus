package com.demo.repository;

//import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.demo.entities.Account;
import com.demo.entities.Address;

@Repository("jpa")
public class JpaAccountRepository implements AccountRepository {
	
	@PersistenceContext
	private EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpa-relationship-demo");
	EntityManager em = factory.createEntityManager();
	
	@Override
	public Account findAccountByNumber(Long accountNumber)
	{
		Account a = em.find(Account.class, accountNumber);
		if(a!=null)
		{
			return a;
		}
		else
			return null;
	}

	@Override
	public List<Account> findAllAccounts() 
	{
		//List<Account> ac = null;
		Query query = em.createQuery("SELECT a FROM account a");
	    return (List<Account>) query.getResultList();
	}

	@Override
	public void save(Account account) 
	{
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.persist(account);	
		em.getTransaction().commit();
	}

	@Override
	public void update(Account account) 
	{
		// TODO Auto-generated method stub
		Account a = em.find(Account.class, account.getAccountNumber());
		a.setAccountNumber(account.getAccountNumber());
		a.setActive(account.isActive());
		a.setEmailAddress(account.getEmailAddress());
		a.setBalance(account.getBalance());
		a.setAddress(account.getAddress());
		a.setBenificiaries(account.getBenificiaries());
	}

	@Override
	public void delete(Account account) 
	{
		// TODO Auto-generated method stub
		if(account!= null)
			em.remove(account);
	}

}
