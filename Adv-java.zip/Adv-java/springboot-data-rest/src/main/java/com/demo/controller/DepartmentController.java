package com.demo.controller;


import java.util.List;

import javax.validation.Valid;
import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.demo.entities.Department;
import com.demo.entities.Employee;
import com.demo.service.DepartmentService;
import com.demo.service.EmployeeService;


@RestController
@RequestMapping("/api/department")
public class DepartmentController 
{

	@Autowired
	private DepartmentService departmentservice;
	
	@GetMapping(path = "")
	public List<Department> getAllDepartment()
	{
		return this.departmentservice.getAllDepartment();
	}
	
	@GetMapping(path = "/{departmentId}")
	public Department getDepartment(@PathVariable("departmentId") Long id)
	{
		return this.departmentservice.getDep(id);
	}
	
	@PostMapping(path ="")
	public Department createDepartment(@Valid @RequestBody Department dep)
	{
		return this.departmentservice.save(dep);
	}
	
	@DeleteMapping(path = "/{departmentId}")
	public Department delete(@PathVariable("departmentId") Long id)
	{
		return this.departmentservice.remove(id);
	}
	
	@PutMapping(path = "/{departmentId}")
	public ResponseEntity<Department>  update(@PathVariable("departmentId") Long id,@Valid @RequestBody Department dep) throws ValidationException
	{
		Department d = this.getDepartment(id);
		if(d!=null)
		{
			d = this.departmentservice.save(dep);
			return  new ResponseEntity<Department>(d, HttpStatus.OK);
		}
		else
		{
			throw new ValidationException("Departmentid not found");
		}
	}
}
