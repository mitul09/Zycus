package com.demo.service;


import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.Department;
import com.demo.repositories.DepartmenRepository;

@Service
@Transactional
public class DepartmentService 
{
	@Autowired
	private DepartmenRepository departmentrepository;
	
	public Department save(Department dep)
	{
		Department d = null;
		if(dep.getDept_id() == null)
		{
			departmentrepository.save(dep);
		}
		else
		{
			d = getDep(dep.getDept_id());
			if(d!=null)
			{
				d.setDept_id(dep.getDept_id());
				d.setDept_name(dep.getDept_name());
				d.setTotal_emp(dep.getTotal_emp());
				d.setEmp(dep.getEmp());
			}
		}
		return d;
			
	}
	public List<Department> getAllDepartment(){
		return departmentrepository.findAll();
	}
	public Department getDep(Long id) {
		Optional<Department> optDepartment =  departmentrepository.findById(id);
		Department d = null;
		if(optDepartment.isPresent())
			d = optDepartment.get();
		
		return d;
	}
	public Department remove(Long id) {
		Department m = getDep(id);
		if(m!=null) {
			departmentrepository.delete(m);
		}
		return m;
	}
}
