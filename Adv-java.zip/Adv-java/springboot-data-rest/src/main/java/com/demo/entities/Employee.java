package com.demo.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
public class Employee 
{
	@Id
	@GeneratedValue
	private Long id;
	
	@NotNull(message ="name cannot be null")
	private String name;
	
	@NotNull(message = "city cannot be null")
	private String city;
	
	@NotNull(message = "salary cannot be null")
	private long salary;
	
	
	public Employee(Long id, String name, String city, long salary) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
		this.salary = salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", city=" + city + ", salary=" + salary + "]";
	}
	
	
	
}
