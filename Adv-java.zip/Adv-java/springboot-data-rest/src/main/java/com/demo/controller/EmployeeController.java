package com.demo.controller;

import java.util.List;

import javax.validation.Valid;
import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.demo.service.EmployeeService;

import com.demo.entities.Employee;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController 
{

	@Autowired
	private EmployeeService employeeservice;
	
	@GetMapping(path = "")
	public List<Employee> getAllEmployee()
	{
		return this.employeeservice.getAllEmployee();
	}
	
	@GetMapping(path = "/{employeeId}")
	public Employee getEmployee(@PathVariable("employeeId") Long id)
	{
		return this.employeeservice.getEmp(id);
	}
	
	@PostMapping(path ="")
	public Employee createEmployee(@Valid @RequestBody Employee emp)
	{
		return this.employeeservice.save(emp);
	}
	
	@DeleteMapping(path = "/{employeeId}")
	public Employee delete(@PathVariable("employeeId") Long id)
	{
		return this.employeeservice.remove(id);
	}
	
	@PutMapping(path = "/{employeeId}")
	public ResponseEntity<Employee>  update(@PathVariable("employeeId") Long id,@Valid @RequestBody Employee emp) throws ValidationException
	{
		Employee e = this.employeeservice.getEmp(id);
		if(e!=null)
		{
			e = this.employeeservice.save(emp);
			return  new ResponseEntity<Employee>(e, HttpStatus.OK);
		}
		else
		{
			throw new ValidationException("employeeid not found");
		}
	}
}
