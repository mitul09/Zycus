package com.demo.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.demo.entities.Employee;

@Entity
public class Department
{
	@Id
	private Long dept_id;
	private String dept_name;
	private Long total_emp;
	
	@OneToMany
	private List<Employee> emp;

	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Department(Long dept_id, String dept_name, Long total_emp, List<Employee> emp) {
		super();
		this.dept_id = dept_id;
		this.dept_name = dept_name;
		this.total_emp = total_emp;
		this.emp = emp;
	}

	public Long getDept_id() {
		return dept_id;
	}

	public void setDept_id(Long dept_id) {
		this.dept_id = dept_id;
	}

	public String getDept_name() {
		return dept_name;
	}

	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}

	public Long getTotal_emp() {
		return total_emp;
	}

	public void setTotal_emp(Long total_emp) {
		this.total_emp = total_emp;
	}

	public List<Employee> getEmp() {
		return emp;
	}

	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "Department [dept_id=" + dept_id + ", dept_name=" + dept_name + ", total_emp=" + total_emp + ", emp="
				+ emp + "]";
	}
	
	
	
}
