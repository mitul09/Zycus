insert into Employee(id,name,city,salary) values(1,"mitul","mumbai",1331);
insert into Employee(id,name,city,salary) values(2,"akash","pune",95331);
insert into Employee(id,name,city,salary) values(3,"zahid","delhi",9331);
insert into Employee(id,name,city,salary) values(4,"deepak","mumbai",7331);
insert into Employee(id,name,city,salary) values(5,"mohit","pune",1531);
