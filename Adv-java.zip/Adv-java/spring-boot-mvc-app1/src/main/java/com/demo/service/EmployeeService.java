package com.demo.service;

import com.demo.repositories.Employeerepository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.Employee;

@Service
@Transactional
public class EmployeeService 
{
	@Autowired
	private Employeerepository employeerepository;
	
	public Employee save(Employee emp)
	{
		Employee e = null;
		if(emp.getId() == null)
		{
			employeerepository.save(emp);
		}
		else
		{
			e = getEmp(emp.getId());
			if(e!=null)
			{
				e.setId(emp.getId());
				e.setName(emp.getName());
				e.setCity(emp.getCity());
				e.setSalary(emp.getSalary());
			}
		}
		return e;
			
	}
	public List<Employee> getAllEmployee(){
		return employeerepository.findAll();
	}
	public Employee getEmp(Long id) {
		Optional<Employee> optEmployee =  employeerepository.findById(id);
		Employee m = null;
		if(optEmployee.isPresent())
			m = optEmployee.get();
		
		return m;
	}
	public Employee remove(Long id) {
		Employee m = getEmp(id);
		if(m!=null) {
			employeerepository.delete(m);
		}
		return m;
	}
	
}
