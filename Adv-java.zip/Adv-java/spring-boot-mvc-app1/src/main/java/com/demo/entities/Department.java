package com.demo.entities;

import java.util.List;

import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.demo.entities.*;
public class Department
{
	@Id
	private Long dept_id;
	private String dept_name;
	private Long total_emp;
	
	@OneToMany
	private List<Employee> emp;
	
	
	
}
